﻿namespace Search.Models
{
    public class GenericFacet
    {
        public object Value { get; set; }

        public long Count { get; set; }
    }
}