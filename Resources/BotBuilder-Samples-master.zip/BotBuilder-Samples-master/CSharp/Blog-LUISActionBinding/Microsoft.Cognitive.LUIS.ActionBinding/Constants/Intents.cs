﻿namespace Microsoft.Cognitive.LUIS.ActionBinding
{
    public static class Intents
    {
        public const string None = "None";
    }
}
